﻿using System.Reflection;
// Assembly SynergyTimer2, Version 2.0.0.0

[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Runtime.InteropServices.Guid("ac9ead6e-c2ba-4700-aed1-0dab8cab6e2a")]
[assembly: System.Reflection.AssemblyCopyright("")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Reflection.AssemblyFileVersion("2.0.0.0")]
[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.DisableOptimizations | System.Diagnostics.DebuggableAttribute.DebuggingModes.EnableEditAndContinue | System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | System.Diagnostics.DebuggableAttribute.DebuggingModes.Default)]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Reflection.AssemblyTitle("Debate Timer 2.0")]
[assembly: System.Reflection.AssemblyDescription("Customizable timer for high school and college policy debate rounds.")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyCompany("Alex Gulakov")]
[assembly: System.Reflection.AssemblyProduct("Debate Timer")]

[assembly: AssemblyVersionAttribute("2.0.0.0")]
